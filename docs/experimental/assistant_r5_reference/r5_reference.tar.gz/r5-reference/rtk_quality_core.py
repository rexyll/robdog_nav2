"""Fail-closed RTK position quality gate.

A receiver-specific adapter must publish explicit FIXED/FLOAT state. The core
never infers carrier solution type from NavSatFix.status or covariance alone.
"""
from __future__ import annotations
from dataclasses import dataclass
from typing import Optional
import math
import numpy as np


@dataclass(frozen=True)
class RtkConfig:
    accepted_solutions: tuple[str, ...] = ("FIXED",)
    max_sigma_fixed_m: float = 0.10
    max_sigma_float_m: float = 0.50
    max_solution_age_s: float = 0.50
    future_tolerance_s: float = 0.10
    max_horizontal_speed_mps: float = 4.0

    def validate(self):
        if not self.accepted_solutions:
            raise ValueError("accepted_solutions cannot be empty")
        if any(s not in {"FIXED", "FLOAT"} for s in self.accepted_solutions):
            raise ValueError("only explicit FIXED/FLOAT states may be accepted")
        thresholds = (self.max_sigma_fixed_m, self.max_sigma_float_m,
                      self.max_solution_age_s, self.max_horizontal_speed_mps,
                      self.future_tolerance_s)
        if not all(math.isfinite(v) for v in thresholds):
            raise ValueError("RTK thresholds must be finite")
        if min(self.max_sigma_fixed_m, self.max_sigma_float_m,
               self.max_solution_age_s, self.max_horizontal_speed_mps) <= 0:
            raise ValueError("RTK thresholds must be positive")
        if self.future_tolerance_s < 0:
            raise ValueError("future_tolerance_s must be non-negative")


@dataclass(frozen=True)
class RtkObservation:
    solution: str
    stamp_s: float
    now_s: float
    x_m: float
    y_m: float
    covariance_xx: float
    covariance_xy: float
    covariance_yy: float


@dataclass(frozen=True)
class RtkDecision:
    accepted: bool
    reason: str
    horizontal_sigma_m: Optional[float] = None
    measured_speed_mps: Optional[float] = None


class RtkQualityGate:
    def __init__(self, config: Optional[RtkConfig] = None):
        self.config = config or RtkConfig()
        self.config.validate()
        self._last_accepted: Optional[tuple[float, float, float]] = None

    def evaluate(self, obs: RtkObservation) -> RtkDecision:
        values = (obs.stamp_s, obs.now_s, obs.x_m, obs.y_m,
                  obs.covariance_xx, obs.covariance_xy, obs.covariance_yy)
        if not all(math.isfinite(v) for v in values):
            return RtkDecision(False, "NON_FINITE_INPUT")
        if obs.solution not in {"FIXED", "FLOAT", "SINGLE", "NONE", "UNKNOWN"}:
            return RtkDecision(False, "UNRECOGNIZED_SOLUTION_TOKEN")
        if obs.solution not in self.config.accepted_solutions:
            return RtkDecision(False, f"SOLUTION_NOT_ACCEPTED:{obs.solution}")
        age = obs.now_s - obs.stamp_s
        if age > self.config.max_solution_age_s:
            return RtkDecision(False, "STALE_SOLUTION")
        if age < -self.config.future_tolerance_s:
            return RtkDecision(False, "FUTURE_TIMESTAMP")

        cov = np.array([[obs.covariance_xx, obs.covariance_xy],
                        [obs.covariance_xy, obs.covariance_yy]], dtype=float)
        eig = np.linalg.eigvalsh(cov)
        if not np.isfinite(eig).all() or float(eig.min()) < -1e-9:
            return RtkDecision(False, "INVALID_HORIZONTAL_COVARIANCE")
        # ROS producers sometimes leave covariance all-zero when it is unknown.
        # Do not interpret that as a physically perfect RTK measurement.
        if float(eig.max()) <= 1e-12:
            return RtkDecision(False, "COVARIANCE_UNSET_OR_ZERO", 0.0)
        if float(eig.min()) <= 1e-12:
            return RtkDecision(False, "COVARIANCE_SINGULAR_OR_UNSET", math.sqrt(max(float(eig.max()), 0.0)))
        sigma = math.sqrt(max(float(eig.max()), 0.0))
        sigma_limit = (self.config.max_sigma_fixed_m if obs.solution == "FIXED"
                       else self.config.max_sigma_float_m)
        if sigma > sigma_limit:
            return RtkDecision(False, "COVARIANCE_TOO_LARGE", sigma)

        speed = None
        if self._last_accepted is not None:
            last_t, last_x, last_y = self._last_accepted
            dt = obs.stamp_s - last_t
            if dt <= 0:
                return RtkDecision(False, "NON_MONOTONIC_TIMESTAMP", sigma)
            speed = math.hypot(obs.x_m - last_x, obs.y_m - last_y) / dt
            if speed > self.config.max_horizontal_speed_mps:
                return RtkDecision(False, "POSITION_JUMP", sigma, speed)

        self._last_accepted = (obs.stamp_s, obs.x_m, obs.y_m)
        return RtkDecision(True, "ACCEPTED", sigma, speed)

# Offline verification report — R5

Date: 2026-11-24

## New work

- Added `robot_dynamic_obstacle_costmap`, a C++ `nav2_costmap_2d::Layer` plugin consuming `/perception/tracked_obstacles` (`robot_interfaces/msg/TrackedObstacleArray`).
- The plugin checks message timestamp/freshness, track observation age, confidence, radius, speed, prediction horizon and track-count bounds; it rejects malformed/non-finite input.
- Obstacle centers and velocity vectors are transformed from the tracked message frame into the local Costmap global frame using TF at the message timestamp. Transform failure invalidates old tracks and makes the layer non-current.
- Message latency and time-since-last-observation are compensated without back-projecting for small future timestamp skew. A bounded constant-velocity segment is marked as a swept disc with configurable radius padding.
- The plugin synchronizes its private Costmap2D origin with rolling-window motion, protects map and callback data with separate mutexes, reports previous/new bounds so old marks can be removed, and becomes non-current when tracked data goes stale.
- `robot_navigation` local Costmap plugin order is now `ObstacleLayer -> DynamicObstacleLayer -> TerrainLayer -> InflationLayer`. The raw LiDAR layer still owns direct sensor marking/raytrace clearing; the dynamic layer adds track-based current-to-predicted regions; the terrain layer adds traversability/unknown-support costs; inflation remains last.
- The detector/tracker path must continuously publish `TrackedObstacleArray`, including empty arrays when no objects exist. Missing/stale input intentionally makes the dynamic layer non-current.

## Passed offline checks

Full `bash scripts_check.sh` run:

- Command guard core: 11/11.
- Sensor health: 6/6.
- State estimation: 6/6.
- Nav2 configuration/safety-chain/terrain/dynamic-layer wiring: 9/9.
- Terrain mapping: 11/11.
- RTK quality gate: 14/14.
- Obstacle tracking: 12/12.
- Terrain-to-Costmap geometry/cost contracts: 10/10.
- Dynamic swept-obstacle geometry and plugin contracts: 23/23.
- Total: **102/102 transport-independent unit and configuration/source-contract tests passed**.
- Python AST parsing: 57 files passed.
- `package.xml` parsing: 12 files passed.
- XML parsing including plugin descriptors: 14 files passed.
- YAML parsing: 11 files passed.
- Shell syntax: 2 scripts passed `bash -n`.
- `setup.py check` metadata checks passed for all ament_python packages.

## Not run / pending

The execution environment is Debian 13 and does not have ROS 2 Jazzy or `colcon`. Therefore `rosdep`, `colcon build`, C++ ABI/API compile validation, generated ROS interfaces, pluginlib discovery, live TF transforms, DDS topic communication and Nav2 local Costmap runtime integration were **not run**. The new C++ plugin is source/config/contract-tested but is not claimed to compile or load yet.

Next required Jazzy validation:

1. `rosdep install --from-paths src --ignore-src -r -y` and `colcon build --symlink-install`.
2. Confirm `robot_dynamic_obstacle_costmap::DynamicObstacleLayer` is found by pluginlib and loaded by `local_costmap`.
3. Publish synthetic tracked obstacles in `odom`, including moving, stationary, stale, low-confidence, malformed and empty arrays.
4. Verify obstacle TF, swept path, rolling Costmap motion, old-mark clearing, non-current transition on timeout and recovery on fresh messages.
5. Exercise crossing tracks, occlusion, ID switches, sudden turns and target disappearance using a detector replay before tuning prediction horizon and padding.

## Safety boundaries

- This plugin provides only a bounded constant-velocity swept region; it does not model intent, abrupt turns, interactions or braking response.
- Track radius/confidence come from the upstream detector and must be validated against the actual camera/LiDAR fusion output.
- All costmap and prediction values are provisional software integration defaults, not calibrated physical parameters or safety certification.
- The plugin does not replace raw LiDAR clearing, hardware emergency stop, vendor base safety functions, or physical collision testing.
- No vendor SDK was connected and no physical robot command was issued.
- `HK-Data20190117_0.db3` remains pending user download; it was not opened or replayed.

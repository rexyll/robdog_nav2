import unittest
import numpy as np
from robot_terrain_mapping.core import TerrainConfig, TerrainEstimator


def regular_surface(z_fn, cfg, samples=4):
    pts = []
    xs = np.linspace(cfg.x_min + 0.02, cfg.x_max - 0.02,
                     int((cfg.x_max-cfg.x_min)/cfg.resolution))
    ys = np.linspace(cfg.y_min + 0.02, cfg.y_max - 0.02,
                     int((cfg.y_max-cfg.y_min)/cfg.resolution))
    for y in ys:
        for x in xs:
            for k in range(samples):
                dx = (k % 2) * 0.02
                dy = (k // 2) * 0.02
                pts.append((x+dx, y+dy, z_fn(x+dx, y+dy)))
    return np.asarray(pts, dtype=float)


class TerrainCoreTests(unittest.TestCase):
    def setUp(self):
        self.cfg = TerrainConfig(resolution=0.25, x_min=0, x_max=2,
                                 y_min=0, y_max=2, min_points_per_cell=2,
                                 max_slope_rad=0.30, max_roughness_m=0.05,
                                 max_step_m=0.12)
        self.est = TerrainEstimator(self.cfg)

    def test_flat_surface_is_low_risk_in_interior(self):
        grid = self.est.estimate(regular_surface(lambda x, y: 0.0, self.cfg))
        interior = grid.traversability[2:-2, 2:-2]
        known = interior[interior >= 0]
        self.assertGreater(known.size, 0)
        self.assertLessEqual(int(np.max(known)), 5)

    def test_steep_ramp_is_blocked(self):
        grid = self.est.estimate(regular_surface(lambda x, y: 0.8*x, self.cfg))
        known = grid.traversability[2:-2, 2:-2]
        self.assertGreater(known.size, 0)
        self.assertTrue(np.any(known == 100))

    def test_step_edge_is_blocked(self):
        grid = self.est.estimate(regular_surface(lambda x, y: 0.0 if x < 1.0 else 0.30, self.cfg))
        self.assertTrue(np.any(grid.traversability == 100))

    def test_within_cell_roughness_is_blocked(self):
        pts = regular_surface(lambda x, y: 0.10 if int(x * 100) % 2 else -0.10, self.cfg)
        grid = self.est.estimate(pts)
        self.assertTrue(np.any(grid.traversability == 100))

    def test_unknown_cells_remain_unknown(self):
        grid = self.est.estimate(np.array([[0.1, 0.1, 0.0], [0.12, 0.1, 0.0]]))
        self.assertTrue(np.all(grid.traversability == -1))

    def test_nan_points_are_ignored(self):
        pts = regular_surface(lambda x, y: 0.0, self.cfg)
        pts = np.vstack([pts, [np.nan, 1.0, 0.0]])
        grid = self.est.estimate(pts)
        self.assertGreater(int(np.count_nonzero(grid.valid)), 0)

    def test_invalid_config_rejected(self):
        with self.assertRaises(ValueError):
            TerrainEstimator(TerrainConfig(resolution=0))

    def test_non_finite_threshold_rejected(self):
        with self.assertRaises(ValueError):
            TerrainEstimator(TerrainConfig(max_slope_rad=float("nan")))

    def test_point_cap_downsamples_bounded_input(self):
        cfg = TerrainConfig(resolution=0.25, x_min=0, x_max=2,
                            y_min=0, y_max=2, min_points_per_cell=1,
                            max_points=10)
        grid = TerrainEstimator(cfg).estimate(np.tile([[0.1, 0.1, 0.0]], (100, 1)))
        self.assertEqual(grid.width, 8)

if __name__ == "__main__":
    unittest.main()

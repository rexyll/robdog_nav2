# R5 reference prototype - disposition

This archive preserves selected Python algorithm cores and their pure-Python tests from the assistant-generated R5 prototype. It is reference material only.

- It is not the `rexyll/robdog_nav2` source tree and was not ROS 2 Jazzy/Humble built.
- The reported 102/102 checks were offline unit/configuration/source-contract checks, not a ROS runtime, pluginlib, Nav2, hardware-in-loop, or robot test.
- It intentionally omits generated ROS package wrappers, message packages, launch files, and custom C++ Nav2 layers because those were not compiled against the repository's pinned ROS/Nav2 versions and do not match the existing `robodog_lite3_bridge` architecture.
- Reuse only after mapping to the repository's actual interfaces and adding CI/build/runtime evidence.
- Do not connect any prototype command guard to a physical robot. Physical E-stop, vendor command API, watchdog, and source odometry remain subject to supplier confirmation and the root TaskPlan.

import unittest
from robot_rtk_quality.core import RtkConfig, RtkObservation, RtkQualityGate


def obs(**kw):
    values = dict(solution="FIXED", stamp_s=10.0, now_s=10.05,
                  x_m=0.0, y_m=0.0, covariance_xx=0.0004,
                  covariance_xy=0.0, covariance_yy=0.0004)
    values.update(kw)
    return RtkObservation(**values)


class RtkGateTests(unittest.TestCase):
    def setUp(self): self.gate = RtkQualityGate()
    def test_explicit_fixed_good_covariance_accepted(self):
        self.assertTrue(self.gate.evaluate(obs()).accepted)
    def test_float_rejected_by_default(self):
        self.assertEqual(self.gate.evaluate(obs(solution="FLOAT")).reason, "SOLUTION_NOT_ACCEPTED:FLOAT")
    def test_unknown_not_inferred_from_covariance(self):
        self.assertFalse(self.gate.evaluate(obs(solution="UNKNOWN")).accepted)
    def test_stale_fix_rejected(self):
        self.assertEqual(self.gate.evaluate(obs(now_s=11)).reason, "STALE_SOLUTION")
    def test_zero_covariance_rejected_as_unset(self):
        self.assertEqual(self.gate.evaluate(obs(covariance_xx=0.0, covariance_yy=0.0)).reason,
                         "COVARIANCE_UNSET_OR_ZERO")
    def test_rank_deficient_covariance_rejected(self):
        self.assertEqual(self.gate.evaluate(obs(covariance_xx=0.0004, covariance_yy=0.0)).reason,
                         "COVARIANCE_SINGULAR_OR_UNSET")
    def test_large_covariance_rejected(self):
        self.assertEqual(self.gate.evaluate(obs(covariance_xx=0.25, covariance_yy=0.25)).reason,
                         "COVARIANCE_TOO_LARGE")
    def test_non_psd_covariance_rejected(self):
        self.assertEqual(self.gate.evaluate(obs(covariance_xx=0.01, covariance_xy=0.1,
                                                covariance_yy=0.01)).reason,
                         "INVALID_HORIZONTAL_COVARIANCE")
    def test_jump_rejected(self):
        self.gate.evaluate(obs())
        result = self.gate.evaluate(obs(stamp_s=10.1, now_s=10.1, x_m=5.0))
        self.assertEqual(result.reason, "POSITION_JUMP")
    def test_non_monotonic_time_rejected(self):
        self.gate.evaluate(obs())
        self.assertEqual(self.gate.evaluate(obs(stamp_s=9.9, now_s=10.0)).reason,
                         "NON_MONOTONIC_TIMESTAMP")
    def test_non_finite_config_rejected(self):
        with self.assertRaises(ValueError):
            RtkQualityGate(RtkConfig(max_sigma_fixed_m=float("nan")))
    def test_float_can_be_enabled_only_explicitly(self):
        gate = RtkQualityGate(RtkConfig(accepted_solutions=("FIXED", "FLOAT")))
        self.assertTrue(gate.evaluate(obs(solution="FLOAT")).accepted)

if __name__ == "__main__": unittest.main()

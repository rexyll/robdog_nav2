"""Small-window 2.5D terrain estimator for a ground-filtered PointCloud2.

This is a conservative baseline, not a full 3D foothold planner. The point cloud
must already be transformed to base_link and filtered enough that the lower
quantile in each XY cell represents the local support surface.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Optional

import numpy as np


@dataclass(frozen=True)
class TerrainConfig:
    resolution: float = 0.20
    x_min: float = -1.0
    x_max: float = 5.0
    y_min: float = -3.0
    y_max: float = 3.0
    min_points_per_cell: int = 3
    elevation_quantile: float = 0.20
    max_slope_rad: float = 0.45
    max_roughness_m: float = 0.06
    max_step_m: float = 0.15
    max_points: int = 200_000

    def validate(self) -> None:
        if not math.isfinite(self.resolution) or self.resolution <= 0:
            raise ValueError("resolution must be finite and > 0")
        if not (self.x_max > self.x_min and self.y_max > self.y_min):
            raise ValueError("grid bounds must have positive extent")
        if self.min_points_per_cell < 1:
            raise ValueError("min_points_per_cell must be >= 1")
        if not 0.0 < self.elevation_quantile <= 0.5:
            raise ValueError("elevation_quantile must be in (0, 0.5]")
        thresholds = (self.max_slope_rad, self.max_roughness_m, self.max_step_m)
        if not all(math.isfinite(v) and v > 0 for v in thresholds):
            raise ValueError("terrain thresholds must be finite and > 0")
        if self.max_points < 1:
            raise ValueError("max_points must be >= 1")


@dataclass
class TerrainGrid:
    resolution: float
    x_min: float
    y_min: float
    elevation_m: np.ndarray
    slope_rad: np.ndarray
    roughness_m: np.ndarray
    step_height_m: np.ndarray
    traversability: np.ndarray  # -1 unknown, 0 easy, 100 blocked
    valid: np.ndarray

    @property
    def height(self) -> int:
        return int(self.elevation_m.shape[0])

    @property
    def width(self) -> int:
        return int(self.elevation_m.shape[1])


class TerrainEstimator:
    def __init__(self, config: Optional[TerrainConfig] = None):
        self.config = config or TerrainConfig()
        self.config.validate()

    def estimate(self, points_xyz: np.ndarray) -> TerrainGrid:
        cfg = self.config
        pts = np.asarray(points_xyz, dtype=np.float64)
        if pts.ndim != 2 or pts.shape[1] < 3:
            raise ValueError("points_xyz must be an Nx3-or-wider array")
        if pts.shape[0] > cfg.max_points:
            # Deterministic stride downsampling avoids unbounded work in callbacks.
            stride = int(math.ceil(pts.shape[0] / cfg.max_points))
            pts = pts[::stride]
        pts = pts[:, :3]
        pts = pts[np.isfinite(pts).all(axis=1)]

        width = int(math.ceil((cfg.x_max - cfg.x_min) / cfg.resolution))
        height = int(math.ceil((cfg.y_max - cfg.y_min) / cfg.resolution))
        shape = (height, width)
        elevation = np.full(shape, np.nan, dtype=np.float32)
        slope = np.full(shape, np.nan, dtype=np.float32)
        roughness = np.full(shape, np.nan, dtype=np.float32)
        step = np.full(shape, np.nan, dtype=np.float32)
        risk = np.full(shape, -1, dtype=np.int8)
        valid = np.zeros(shape, dtype=np.uint8)
        if pts.size == 0:
            return TerrainGrid(cfg.resolution, cfg.x_min, cfg.y_min,
                               elevation, slope, roughness, step, risk, valid)

        ix = np.floor((pts[:, 0] - cfg.x_min) / cfg.resolution).astype(np.int64)
        iy = np.floor((pts[:, 1] - cfg.y_min) / cfg.resolution).astype(np.int64)
        inside = ((pts[:, 0] >= cfg.x_min) & (pts[:, 0] < cfg.x_max) &
                  (pts[:, 1] >= cfg.y_min) & (pts[:, 1] < cfg.y_max) &
                  (ix >= 0) & (ix < width) & (iy >= 0) & (iy < height))
        ix, iy, z = ix[inside], iy[inside], pts[inside, 2]
        buckets: dict[tuple[int, int], list[float]] = {}
        for x_i, y_i, z_i in zip(ix, iy, z):
            buckets.setdefault((int(y_i), int(x_i)), []).append(float(z_i))

        for (row, col), values in buckets.items():
            if len(values) < cfg.min_points_per_cell:
                continue
            vals = np.asarray(values, dtype=np.float64)
            center = float(np.quantile(vals, cfg.elevation_quantile))
            mad = float(np.median(np.abs(vals - np.median(vals))))
            elevation[row, col] = center
            roughness[row, col] = 1.4826 * mad
            valid[row, col] = 1

        # Estimate local gradients and step discontinuity from neighboring cell
        # surface heights. Cells without an X and Y gradient stay UNKNOWN.
        for row in range(height):
            for col in range(width):
                if not valid[row, col]:
                    continue
                z0 = float(elevation[row, col])
                neighbors: list[float] = []
                dx = self._axis_gradient(elevation, valid, row, col, axis=1, resolution=cfg.resolution)
                dy = self._axis_gradient(elevation, valid, row, col, axis=0, resolution=cfg.resolution)
                if dx is None or dy is None:
                    continue
                for dr in (-1, 0, 1):
                    for dc in (-1, 0, 1):
                        if dr == 0 and dc == 0:
                            continue
                        rr, cc = row + dr, col + dc
                        if 0 <= rr < height and 0 <= cc < width and valid[rr, cc]:
                            neighbors.append(abs(float(elevation[rr, cc]) - z0))
                step_m = max(neighbors, default=0.0)
                slope_rad = math.atan(math.hypot(dx, dy))
                slope[row, col] = slope_rad
                step[row, col] = step_m
                rough_m = float(roughness[row, col])
                if (slope_rad >= cfg.max_slope_rad or
                    rough_m >= cfg.max_roughness_m or
                    step_m >= cfg.max_step_m):
                    risk[row, col] = 100
                else:
                    normalized = (
                        0.55 * slope_rad / cfg.max_slope_rad +
                        0.25 * rough_m / cfg.max_roughness_m +
                        0.20 * step_m / cfg.max_step_m
                    )
                    risk[row, col] = np.int8(np.clip(round(100.0 * normalized), 0, 99))

        return TerrainGrid(cfg.resolution, cfg.x_min, cfg.y_min,
                           elevation, slope, roughness, step, risk, valid)

    @staticmethod
    def _axis_gradient(elevation: np.ndarray, valid: np.ndarray,
                       row: int, col: int, axis: int, resolution: float) -> Optional[float]:
        if axis == 1:
            before = (row, col - 1)
            after = (row, col + 1)
        else:
            before = (row - 1, col)
            after = (row + 1, col)
        h, w = valid.shape
        b_ok = 0 <= before[0] < h and 0 <= before[1] < w and bool(valid[before])
        a_ok = 0 <= after[0] < h and 0 <= after[1] < w and bool(valid[after])
        z0 = float(elevation[row, col])
        if b_ok and a_ok:
            return (float(elevation[after]) - float(elevation[before])) / (2.0 * resolution)
        if a_ok:
            return (float(elevation[after]) - z0) / resolution
        if b_ok:
            return (z0 - float(elevation[before])) / resolution
        return None

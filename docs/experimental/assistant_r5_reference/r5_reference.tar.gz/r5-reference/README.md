# Quadruped navigation ROS 2 workspace scaffold

This workspace currently establishes the first ROS message contracts and a
software-only command safety path. It is not yet a complete navigation stack.

## Packages

- `robot_interfaces`: project-owned base status and command-guard diagnostic messages.
- `robot_cmd_guard_core`: transport-independent fail-closed logic with Python unit tests.
- `robot_cmd_guard`: ROS 2 Jazzy node wrapping the safety core.
- `robot_mock_base`: status publisher and safe-command observer; never actuates hardware.
- `robot_sensor_health`: freshness, receipt-rate, frame ID and timestamp diagnostics for LiDAR, cameras, IMU and GNSS.
- `robot_state_estimation`: local EKF and gated dual-EKF + GNSS transform templates.
- `robot_navigation`: PointCloud2 costmap fragment, Collision Monitor configuration, TwistStamped contract, and a downstream software-only safety-chain launch.

## Build

```bash
source /opt/ros/jazzy/setup.bash
cd quadruped_ws
rosdep install --from-paths src --ignore-src -r -y
colcon build --symlink-install
source install/setup.bash
```

## Software-only smoke test

Single software-only launch (mock base + command guard):

```bash
ros2 launch robot_cmd_guard sim_guard_demo.launch.py
```

In another terminal, stream a test command in the base frame (Ctrl-C to stop):

```bash
ros2 topic pub -r 10 /cmd_vel_nav geometry_msgs/msg/TwistStamped \
  '{header: {frame_id: base_link}, twist: {linear: {x: 0.1}, angular: {z: 0.0}}}'
```

Observe:

```bash
ros2 topic echo /cmd_vel_safe
ros2 topic echo /safety/cmd_guard_status
ros2 topic echo /mock_base/observed_safe_cmd
```

In a separate terminal, launch sensor stream diagnostics once the normalized sensor topics exist:

```bash
ros2 launch robot_sensor_health sensor_health.launch.py
ros2 topic echo /diagnostics
```

The launch default uses `robot_cmd_guard/config/sim_only.yaml`. Values are
illustrative software-test limits only and MUST NOT be loaded on a physical
machine dog. Physical integration is prohibited until exact robot, gait,
payload and terrain limits and vendor stop semantics are documented.

Once normalized sensor topics are available, record sensor, TF, base and safety
streams with `bash scripts/record_sensors.sh [optional-output-directory]`.
The list is a template and must be aligned with the actual driver topic names.

## Added state estimation and navigation packages (templates)

- `robot_state_estimation`: local EKF and dual EKF + GNSS transform parameter/launch templates. The GNSS launch is gated on earth-referenced yaw calibration and correct TF ownership.
- `robot_navigation`: Nav2 PointCloud2 2D-obstacle baseline, Collision Monitor software-only parameter/launch template, and a TwistStamped topic contract. It is not a complete Nav2 bringup and not ready for physical deployment.

Run the expanded static/unit checks with:

```bash
bash scripts_check.sh
```

The checker runs pure Python tests and parses package XML/YAML. It does not replace a real `rosdep` + `colcon build` or runtime simulation in ROS 2 Jazzy.


Downstream Nav2 safety chain (still software-only; requires upstream Nav2
Velocity Smoother on `/cmd_vel_smoothed`, PointCloud2 on
`/sensors/lidar/points`, and valid `odom -> base_link` TF):

```bash
ros2 launch robot_navigation sim_safety_chain.launch.py use_sim_time:=true
```

This starts a mock base, Collision Monitor, and command guard. It does not
start Controller Server / Velocity Smoother and does not actuate a robot.
Missing/stale point clouds or TF are expected to block/stop commands.


## Terrain, RTK quality and dynamic obstacle tracking baselines

Additional packages now include:

- `robot_terrain_costmap`: a Nav2 Costmap2D C++ plugin that projects TerrainGrid cells into the local costmap; transforms the source grid into the costmap global frame, maps traversability risk to Nav2 costs, and treats unknown terrain as lethal by default.
- `robot_terrain_mapping`: a local 2.5D low-envelope terrain grid from a PointCloud2 already transformed to `base_link`; outputs elevation, slope, roughness, adjacent step height and risk/unknown state. Not yet a foothold planner or Nav2 plugin.
- `robot_rtk_quality`: gates `/odometry/gps` using explicit receiver solution state, timestamp correlation, horizontal covariance, measurement age and position-jump checks. The global EKF consumes `/odometry/gps_qualified`. A vendor adapter must publish `RtkSolutionStatus`; FIXED/FLOAT is never inferred from `NavSatFix.status`.
- `robot_obstacle_tracking`: nearest-neighbor + alpha-beta tracking for already detected and clustered obstacle centroids in one stable frame. It is not a raw point-cloud/camera detector.

Launch independently after `colcon build`:

```bash
ros2 launch robot_terrain_mapping terrain_mapping.launch.py
ros2 launch robot_rtk_quality rtk_quality.launch.py
ros2 launch robot_obstacle_tracking obstacle_tracking.launch.py
```

These additions are transport-independent unit-tested but have not been built or run under ROS 2 Jazzy in the current environment.


## Terrain-aware local costmap layer (P0 integration)

A new C++ plugin package, `robot_terrain_costmap`, consumes `/terrain/local_grid`
from `robot_terrain_mapping`. The local costmap fragment now orders layers as
`ObstacleLayer -> DynamicObstacleLayer -> TerrainLayer -> InflationLayer`, so
raw sensor obstacles, tracked dynamic-object swept regions, and terrain risk are
composed before the final inflation pass.
The plugin synchronizes its private Costmap2D origin with the robot pose on
rolling-window updates, matching Nav2 ObstacleLayer behavior. Its internal grid
is protected by the Costmap2D mutex while reading/writing, separately from the
TerrainGrid callback data mutex.

The plugin transforms each source cell from the message frame into the costmap
global frame at the message timestamp. Because terrain-grid cells may be larger
than the costmap resolution and the robot frame can rotate, each transformed
cell is rasterized through a conservative axis-aligned world-frame bounding box.
This can over-block corners under rotation, but avoids gaps between cells.

Risk mapping: risk 0..99 maps monotonically to Nav2 costs 0..252; risk 100 maps
to lethal (254); unknown or invalid support cells are lethal by default.
Zero-risk cells do not clear master unknown space; the local costmap uses
`track_unknown_space: true` and relies on the LiDAR obstacle layer's clearing
observations to mark collision-free space. If TerrainGrid becomes stale, the
plugin reports `current=false`; Nav2 should not
be considered navigation-ready.

This is a 2D projection of terrain risk, not 3D foothold planning, dynamic
obstacle tracking integration, or a certified quadruped stability model. It
remains a local-costmap-only template until the custom plugin has been built and
run under ROS 2 Jazzy with real TF and synthetic terrain messages.


## Dynamic obstacle navigation integration (R5)

The local Nav2 costmap template now composes four layers in this order:

`ObstacleLayer -> DynamicObstacleLayer -> TerrainLayer -> InflationLayer`.

`robot_obstacle_tracking` publishes `TrackedObstacleArray` to `/perception/tracked_obstacles`; the new `robot_dynamic_obstacle_costmap` plugin validates track freshness/confidence, transforms tracks into the local costmap frame, and marks a bounded current-to-predicted swept region. The raw LiDAR obstacle layer remains responsible for direct sensor marking and raytrace clearing. The terrain layer remains responsible for terrain risk / unknown support.

All prediction and padding parameters are provisional integration defaults. This plugin has source and offline-contract validation only; it has not yet been compiled or loaded in ROS 2 Jazzy. Do not connect it to a physical robot until Jazzy runtime, TF timing, sensor tracking, stopping-distance and failure-injection tests are complete.

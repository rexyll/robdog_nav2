import math
import unittest

from robot_dynamic_obstacle_costmap.core import (
    TrackedObstacle, make_swept_disc, sample_swept_disc, swept_bounds,
)


class DynamicObstacleGeometryTest(unittest.TestCase):
    def setUp(self):
        self.track = TrackedObstacle(
            x=1.0, y=2.0, vx=1.0, vy=0.0, radius_m=0.25,
            confidence=0.9, time_since_seen_s=0.0, prediction_horizon_s=0.5,
        )

    def test_current_to_future_sweep(self):
        disc = make_swept_disc(self.track, message_age_s=0.0)
        self.assertIsNotNone(disc)
        self.assertAlmostEqual(disc.start_x, 1.0)
        self.assertAlmostEqual(disc.end_x, 1.5)
        self.assertAlmostEqual(disc.radius_m, 0.40)

    def test_message_latency_compensation(self):
        disc = make_swept_disc(self.track, message_age_s=0.1)
        self.assertAlmostEqual(disc.start_x, 1.1)
        self.assertAlmostEqual(disc.end_x, 1.6)

    def test_track_observation_age_compensation(self):
        track = TrackedObstacle(**{**self.track.__dict__, "time_since_seen_s": 0.2})
        disc = make_swept_disc(track, message_age_s=0.1)
        self.assertAlmostEqual(disc.start_x, 1.3)

    def test_stale_message_rejected(self):
        self.assertIsNone(make_swept_disc(self.track, message_age_s=0.31))

    def test_stale_track_rejected(self):
        track = TrackedObstacle(**{**self.track.__dict__, "time_since_seen_s": 0.26})
        self.assertIsNone(make_swept_disc(track, message_age_s=0.0))

    def test_low_confidence_rejected(self):
        track = TrackedObstacle(**{**self.track.__dict__, "confidence": 0.1})
        self.assertIsNone(make_swept_disc(track, message_age_s=0.0))

    def test_invalid_radius_rejected(self):
        track = TrackedObstacle(**{**self.track.__dict__, "radius_m": 0.0})
        self.assertIsNone(make_swept_disc(track, message_age_s=0.0))

    def test_speed_is_clamped(self):
        track = TrackedObstacle(**{**self.track.__dict__, "vx": 100.0})
        disc = make_swept_disc(track, message_age_s=0.0, max_speed_mps=2.0)
        self.assertAlmostEqual(disc.end_x - disc.start_x, 1.0)

    def test_prediction_horizon_is_clamped(self):
        track = TrackedObstacle(**{**self.track.__dict__, "prediction_horizon_s": 5.0})
        disc = make_swept_disc(track, message_age_s=0.0, max_prediction_horizon_s=0.2)
        self.assertAlmostEqual(disc.end_x - disc.start_x, 0.2)

    def test_non_finite_data_rejected(self):
        track = TrackedObstacle(**{**self.track.__dict__, "vx": math.nan})
        self.assertIsNone(make_swept_disc(track, message_age_s=0.0))

    def test_small_future_timestamp_skew_is_clamped(self):
        disc = make_swept_disc(self.track, message_age_s=-0.01)
        self.assertAlmostEqual(disc.start_x, self.track.x)

    def test_far_future_message_rejected(self):
        self.assertIsNone(make_swept_disc(self.track, message_age_s=-0.06))

    def test_samples_cover_segment_with_bounded_spacing(self):
        disc = make_swept_disc(self.track, message_age_s=0.0)
        samples = sample_swept_disc(disc, 0.1)
        self.assertEqual(samples[0], (disc.start_x, disc.start_y))
        self.assertEqual(samples[-1], (disc.end_x, disc.end_y))
        for a, b in zip(samples, samples[1:]):
            self.assertLessEqual(math.dist(a, b), 0.1 + 1e-12)

    def test_bounds_include_radius_and_motion(self):
        disc = make_swept_disc(self.track, message_age_s=0.0)
        bounds = swept_bounds([disc])
        self.assertAlmostEqual(bounds[0], 0.6)
        self.assertAlmostEqual(bounds[1], 1.6)
        self.assertAlmostEqual(bounds[2], 1.9)
        self.assertAlmostEqual(bounds[3], 2.4)

    def test_empty_bounds(self):
        self.assertIsNone(swept_bounds([]))

    def test_sample_spacing_validation(self):
        with self.assertRaises(ValueError):
            sample_swept_disc(make_swept_disc(self.track, message_age_s=0.0), 0.0)


if __name__ == "__main__":
    unittest.main()

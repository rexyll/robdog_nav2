"""Deterministic 2D nearest-neighbor + alpha-beta obstacle tracker.

Input detections must already be clustered/detected and expressed in one stable
world frame (normally odom). This is a baseline tracker, not a detector.
"""
from __future__ import annotations
from dataclasses import dataclass
import math
from typing import Iterable, Optional


@dataclass(frozen=True)
class Detection:
    x: float
    y: float
    z: float = 0.0
    radius_m: float = 0.25
    confidence: float = 1.0


@dataclass
class Track:
    track_id: int
    x: float
    y: float
    z: float
    vx: float
    vy: float
    vz: float
    radius_m: float
    confidence: float
    age_frames: int
    first_stamp_s: float
    last_stamp_s: float
    last_seen_s: float


@dataclass(frozen=True)
class TrackerConfig:
    association_distance_m: float = 1.0
    alpha: float = 0.65
    beta: float = 0.18
    max_track_age_s: float = 0.8
    min_confidence: float = 0.15
    min_radius_m: float = 0.05
    max_radius_m: float = 2.0
    prediction_horizon_s: float = 0.8
    max_track_speed_mps: float = 20.0

    def validate(self):
        numeric = (self.association_distance_m, self.alpha, self.beta,
                   self.max_track_age_s, self.min_confidence,
                   self.min_radius_m, self.max_radius_m, self.prediction_horizon_s,
                   self.max_track_speed_mps)
        if not all(math.isfinite(v) for v in numeric):
            raise ValueError("tracker parameters must be finite")
        if self.association_distance_m <= 0 or self.max_track_age_s <= 0:
            raise ValueError("association distance and track age must be positive")
        if self.min_radius_m <= 0 or self.max_radius_m < self.min_radius_m:
            raise ValueError("invalid obstacle radius range")
        if self.prediction_horizon_s < 0 or self.max_track_speed_mps <= 0:
            raise ValueError("prediction horizon must be non-negative and max speed positive")
        if not 0 < self.alpha <= 1 or not 0 <= self.beta <= 1:
            raise ValueError("alpha must be (0,1], beta must be [0,1]")
        if not 0 <= self.min_confidence <= 1:
            raise ValueError("min_confidence must be [0,1]")


class ObstacleTracker:
    def __init__(self, config: Optional[TrackerConfig] = None):
        self.config = config or TrackerConfig()
        self.config.validate()
        self.tracks: dict[int, Track] = {}
        self._next_id = 1
        self._last_frame_stamp: Optional[float] = None

    def update(self, detections: Iterable[Detection], stamp_s: float) -> list[Track]:
        if not math.isfinite(stamp_s):
            raise ValueError("stamp_s must be finite")
        if self._last_frame_stamp is not None and stamp_s <= self._last_frame_stamp:
            raise ValueError("detection timestamps must be strictly increasing")
        self._last_frame_stamp = stamp_s
        cfg = self.config
        # Expire stale tracks before association; otherwise a long-missing object
        # could accidentally reclaim an old ID when it reappears nearby.
        stale_before_match = [tid for tid, track in self.tracks.items()
                              if stamp_s - track.last_seen_s > cfg.max_track_age_s]
        for tid in stale_before_match:
            del self.tracks[tid]
        dets = [d for d in detections if self._valid_detection(d)]
        tracks = list(self.tracks.values())
        candidates = []
        for ti, track in enumerate(tracks):
            dt = max(stamp_s - track.last_stamp_s, 1e-6)
            px, py = track.x + track.vx * dt, track.y + track.vy * dt
            for di, det in enumerate(dets):
                dist = math.hypot(det.x - px, det.y - py)
                if dist <= cfg.association_distance_m:
                    candidates.append((dist, ti, di, px, py, dt))
        candidates.sort(key=lambda item: (item[0], tracks[item[1]].track_id, item[2]))
        used_tracks, used_dets = set(), set()
        for _, ti, di, px, py, dt in candidates:
            if ti in used_tracks or di in used_dets:
                continue
            used_tracks.add(ti); used_dets.add(di)
            track, det = tracks[ti], dets[di]
            rx, ry = det.x - px, det.y - py
            track.x = px + cfg.alpha * rx
            track.y = py + cfg.alpha * ry
            track.z = track.z + cfg.alpha * (det.z - track.z)
            track.vx += cfg.beta * rx / dt
            track.vy += cfg.beta * ry / dt
            planar_speed = math.hypot(track.vx, track.vy)
            if planar_speed > cfg.max_track_speed_mps:
                scale = cfg.max_track_speed_mps / planar_speed
                track.vx *= scale
                track.vy *= scale
            track.vz = 0.7 * track.vz + 0.3 * (det.z - track.z) / dt
            track.radius_m = 0.7 * track.radius_m + 0.3 * det.radius_m
            track.confidence = max(0.0, min(1.0, 0.6 * track.confidence + 0.4 * det.confidence))
            track.age_frames += 1
            track.last_stamp_s = stamp_s
            track.last_seen_s = stamp_s
        for di, det in enumerate(dets):
            if di in used_dets:
                continue
            track = Track(self._next_id, det.x, det.y, det.z, 0.0, 0.0, 0.0,
                          det.radius_m, det.confidence, 1, stamp_s, stamp_s, stamp_s)
            self.tracks[self._next_id] = track
            self._next_id += 1
        stale = [tid for tid, track in self.tracks.items()
                 if stamp_s - track.last_seen_s > cfg.max_track_age_s]
        for tid in stale:
            del self.tracks[tid]
        return sorted(self.tracks.values(), key=lambda t: t.track_id)

    def _valid_detection(self, d: Detection) -> bool:
        vals = (d.x, d.y, d.z, d.radius_m, d.confidence)
        return (all(math.isfinite(v) for v in vals) and
                self.config.min_confidence <= d.confidence <= 1.0 and
                self.config.min_radius_m <= d.radius_m <= self.config.max_radius_m)

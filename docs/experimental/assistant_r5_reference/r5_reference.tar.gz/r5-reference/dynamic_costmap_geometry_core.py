from __future__ import annotations

from dataclasses import dataclass
import math
from typing import Iterable


@dataclass(frozen=True)
class TrackedObstacle:
    x: float
    y: float
    vx: float
    vy: float
    radius_m: float
    confidence: float
    time_since_seen_s: float
    prediction_horizon_s: float


@dataclass(frozen=True)
class SweptDisc:
    start_x: float
    start_y: float
    end_x: float
    end_y: float
    radius_m: float


def make_swept_disc(
    track: TrackedObstacle,
    *,
    message_age_s: float,
    max_message_age_s: float = 0.30,
    max_future_stamp_s: float = 0.05,
    max_track_age_s: float = 0.25,
    min_confidence: float = 0.35,
    max_radius_m: float = 2.0,
    max_speed_mps: float = 8.0,
    max_prediction_horizon_s: float = 0.60,
    radius_padding_m: float = 0.15,
) -> SweptDisc | None:
    """Validate a track and produce its current-to-future swept disc.

    Coordinates are assumed to have already been transformed into the costmap
    global frame. This helper mirrors the C++ plugin's time compensation and
    bounded constant-velocity prediction policy.
    """
    values = (
        track.x, track.y, track.vx, track.vy, track.radius_m,
        track.confidence, track.time_since_seen_s,
        track.prediction_horizon_s, message_age_s, max_message_age_s,
        max_future_stamp_s, max_track_age_s, min_confidence, max_radius_m, max_speed_mps,
        max_prediction_horizon_s, radius_padding_m,
    )
    if not all(math.isfinite(v) for v in values):
        return None
    if (max_message_age_s < 0.0 or max_future_stamp_s < 0.0 or max_track_age_s < 0.0 or
        message_age_s < -max_future_stamp_s or message_age_s > max_message_age_s):
        return None
    # Small timestamp skew is tolerated, but must never back-project an obstacle.
    message_age_s = max(0.0, message_age_s)
    if track.time_since_seen_s < 0.0 or track.time_since_seen_s > max_track_age_s:
        return None
    if not 0.0 <= min_confidence <= 1.0 or not min_confidence <= track.confidence <= 1.0:
        return None
    if track.radius_m <= 0.0 or track.radius_m > max_radius_m:
        return None
    if max_speed_mps <= 0.0 or max_prediction_horizon_s < 0.0 or radius_padding_m < 0.0:
        return None
    if track.prediction_horizon_s < 0.0:
        return None

    speed = math.hypot(track.vx, track.vy)
    if speed > max_speed_mps:
        scale = max_speed_mps / speed
        vx, vy = track.vx * scale, track.vy * scale
    else:
        vx, vy = track.vx, track.vy

    effective_age = message_age_s + track.time_since_seen_s
    start_x = track.x + vx * effective_age
    start_y = track.y + vy * effective_age
    horizon = min(track.prediction_horizon_s, max_prediction_horizon_s)
    end_x = start_x + vx * horizon
    end_y = start_y + vy * horizon
    radius = track.radius_m + radius_padding_m
    if not all(math.isfinite(v) for v in (start_x, start_y, end_x, end_y, radius)):
        return None
    return SweptDisc(start_x, start_y, end_x, end_y, radius)


def sample_swept_disc(disc: SweptDisc, max_spacing_m: float) -> list[tuple[float, float]]:
    """Return inclusive, evenly spaced center samples along a swept segment."""
    if not math.isfinite(max_spacing_m) or max_spacing_m <= 0.0:
        raise ValueError("max_spacing_m must be finite and positive")
    distance = math.hypot(disc.end_x - disc.start_x, disc.end_y - disc.start_y)
    steps = max(1, math.ceil(distance / max_spacing_m))
    return [
        (
            disc.start_x + (disc.end_x - disc.start_x) * i / steps,
            disc.start_y + (disc.end_y - disc.start_y) * i / steps,
        )
        for i in range(steps + 1)
    ]


def swept_bounds(discs: Iterable[SweptDisc]) -> tuple[float, float, float, float] | None:
    """Return world AABB including each disc's radius, or None when empty."""
    items = list(discs)
    if not items:
        return None
    return (
        min(min(d.start_x, d.end_x) - d.radius_m for d in items),
        min(min(d.start_y, d.end_y) - d.radius_m for d in items),
        max(max(d.start_x, d.end_x) + d.radius_m for d in items),
        max(max(d.start_y, d.end_y) + d.radius_m for d in items),
    )

import unittest
from robot_obstacle_tracking.core import Detection, ObstacleTracker, TrackerConfig

class TrackerTests(unittest.TestCase):
    def setUp(self): self.tracker = ObstacleTracker()
    def test_new_detection_creates_track(self):
        tracks = self.tracker.update([Detection(0, 0)], 1.0)
        self.assertEqual(len(tracks), 1)
        self.assertEqual(tracks[0].track_id, 1)
    def test_moving_detection_estimates_velocity(self):
        self.tracker.update([Detection(0, 0)], 1.0)
        tracks = self.tracker.update([Detection(0.2, 0)], 1.1)
        self.assertEqual(len(tracks), 1)
        self.assertGreater(tracks[0].vx, 0.0)
    def test_gated_match_creates_new_track(self):
        self.tracker.update([Detection(0, 0)], 1.0)
        tracks = self.tracker.update([Detection(5, 0)], 1.1)
        self.assertEqual(len(tracks), 2)
    def test_stale_track_expires(self):
        self.tracker.update([Detection(0, 0)], 1.0)
        tracks = self.tracker.update([], 2.0)
        self.assertEqual(tracks, [])
    def test_expired_track_reappearance_gets_new_id(self):
        self.tracker.update([Detection(0, 0)], 1.0)
        tracks = self.tracker.update([Detection(0.1, 0)], 2.0)
        self.assertEqual(len(tracks), 1)
        self.assertEqual(tracks[0].track_id, 2)
    def test_low_confidence_dropped(self):
        self.assertEqual(self.tracker.update([Detection(0, 0, confidence=0.01)], 1.0), [])
    def test_non_monotonic_stamp_rejected(self):
        self.tracker.update([], 1.0)
        with self.assertRaises(ValueError): self.tracker.update([], 1.0)
    def test_non_finite_config_rejected(self):
        with self.assertRaises(ValueError):
            ObstacleTracker(TrackerConfig(alpha=float("nan")))
    def test_track_speed_is_bounded(self):
        tracker = ObstacleTracker(TrackerConfig(association_distance_m=5.0,
                                                 max_track_speed_mps=2.0,
                                                 beta=1.0, alpha=1.0))
        tracker.update([Detection(0, 0)], 1.0)
        tracks = tracker.update([Detection(1, 0)], 1.1)
        self.assertLessEqual(abs(tracks[0].vx), 2.0)
    def test_prediction_horizon_is_validated(self):
        with self.assertRaises(ValueError):
            ObstacleTracker(TrackerConfig(prediction_horizon_s=-0.1))
    def test_tracks_have_stable_ids(self):
        self.tracker.update([Detection(0,0), Detection(3,0)], 1.0)
        tracks = self.tracker.update([Detection(0.1,0), Detection(3.1,0)], 1.1)
        self.assertEqual([t.track_id for t in tracks], [1,2])

if __name__ == "__main__": unittest.main()
